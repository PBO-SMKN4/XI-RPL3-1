/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ASUS
 */
public class Pelanggaran {
    public String no_pelanggaran;
    public String jenis_pelanggaran;
    public int poin_pelanggaran;
    
    public void setNoPelanggaran(String no_pelanggaran){
        this.no_pelanggaran = no_pelanggaran;
    }
    
    public String getNoPelanggaran(){
        return no_pelanggaran;
    }
    
    public void setJenisPelanggaran(String jenis_pelanggaran){
        this.jenis_pelanggaran = jenis_pelanggaran;
    }
    
    public String getJenisPelanggaran(){
        return jenis_pelanggaran;
    }
    
    public void setPoinPelanggaran(int poin_pelanggaran){
        this.poin_pelanggaran = poin_pelanggaran;
    }
    
    public int getPoinPelanggaran(){
        return poin_pelanggaran;
    }   
}
