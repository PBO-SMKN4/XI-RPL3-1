/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ASUS
 */
public class Siswa extends WargaSekolah {
    private String nis;
    private String kelas;
    private int poin_siswa;
    
    @Override
    public void setStatus(String status){
        this.status = "Siswa";
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setNIS(String nis){
        this.nis = nis;
    }
    
    public String getNIS(){
        return nis;
    }
    
    @Override
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setKelas(String kelas){
        this.kelas = kelas;
    }
    
    public String getKelas(){
        return kelas;
    }
    
    public void setPoinSiswa(int poin_siswa){
        this.poin_siswa = poin_siswa;
    }
    
    public int getPoinSiswa(){
        return poin_siswa;
    }
}
