/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ASUS
 */
public class JenisPelanggaran extends Pelanggaran {
    Pelanggaran terlambat = new Pelanggaran();
    Pelanggaran sepatu = new Pelanggaran();
    Pelanggaran celanarok = new Pelanggaran();
    Pelanggaran rambut = new Pelanggaran();
    Pelanggaran pakaian = new Pelanggaran();
    
    public JenisPelanggaran(){
        terlambat.setNoPelanggaran("001");
        terlambat.setJenisPelanggaran("Terlambat datang ke sekolah");
        terlambat.setPoinPelanggaran(10);
        
        sepatu.setNoPelanggaran("002");
        sepatu.setJenisPelanggaran("Sepatu tidak sesuai aturan");
        sepatu.setPoinPelanggaran(5);
        
        celanarok.setNoPelanggaran("003");
        celanarok.setJenisPelanggaran("Celana/rok tidak sesuai aturan");
        celanarok.setPoinPelanggaran(5);
        
        rambut.setNoPelanggaran("004");
        rambut.setJenisPelanggaran("Rambut tidak sesuai aturan");
        rambut.setPoinPelanggaran(5);
        
        pakaian.setNoPelanggaran("005");
        pakaian.setJenisPelanggaran("Pakaian tidak sesuai hari");
        pakaian.setPoinPelanggaran(5);
    }
}
