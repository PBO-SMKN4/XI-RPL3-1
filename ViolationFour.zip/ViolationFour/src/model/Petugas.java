/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author ASUS
 */
public class Petugas extends WargaSekolah {
   private String id_petugas;
   private String username;
   private String password;
   
   @Override
   public void setStatus(String status){
        this.status = "Petugas";
    }
   
    public String getStatus(){
        return status;
    }
    
    public void setIdPetugas(String id_petugas){
        this.id_petugas = id_petugas;
    }
   
    public String getIdPetugas(){
        return id_petugas;
    }
    
    @Override
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setUsername(String username){
        this.username = username;
    }
    
    public String getUsername(){
        return username;
    }
    
    public void setPassword(String password){
        this.password = password;
    }
    
    public String getPassword(){
        return password;
    }   
}
