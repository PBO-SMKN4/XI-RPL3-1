/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package form;

import controller.DatabaseConnection;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class ManageDataPelanggaran extends javax.swing.JDialog {

    /**
     * Creates new form ManageData
     */
    Connection koneksi;
    String action;
    public ManageDataPelanggaran(java.awt.Frame parent, boolean modal, String act, String nis) {
        super(parent, modal);
        initComponents();
        setTitle("Violation Four");
        koneksi = DatabaseConnection.getKoneksi("localhost", "3306", "root", "", "db_violationfour");
        ComboPelanggaran();
        
        action = act;
        if(action.equals("Edit")){
            txtNIS.setEnabled(false);
            txtNama.setEnabled(false);
            cmbKelas.setEnabled(false);
            showData(nis);
        }
    }
    
    private void DataSiswa(){
        String nis = txtNIS.getText();
        try{
            Statement stmt = koneksi.createStatement();
            String query = "SELECT * FROM t_siswa WHERE nis = "+nis;
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                String kelas = rs.getString("kelas");
                txtNama.setText(rs.getString("nama_lengkap"));
                cmbKelas.getModel().setSelectedItem(kelas);
                txtPoinSiswa.setText(rs.getString("poin_siswa"));
            }
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan!");
        }
    }
    
    private void ComboPelanggaran(){
        try{
            Statement stmt = koneksi.createStatement();
            String query = "SELECT * FROM t_pelanggaran";
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                String jenispelanggaran = rs.getString("jenis_pelanggaran");
                cmbPelanggaran.addItem(jenispelanggaran);
            }
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan pada database!");
        }
    }
    
    private void SelectedPelanggaran(){
        String jenis = cmbPelanggaran.getSelectedItem().toString();
        try{
            Statement stmt = koneksi.createStatement();
            String query = "SELECT poin_pelanggaran FROM t_pelanggaran WHERE jenis_pelanggaran = '"+jenis+"'";
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                txtPoinPelanggaran.setText(rs.getString("poin_pelanggaran"));
            }
        }catch(SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan pada database!");
        }
    }
    
    private void JumlahPoin(){
        int poinsiswa = Integer.parseInt(txtPoinSiswa.getText());
        int poinpelanggaran = Integer.parseInt(txtPoinPelanggaran.getText());
        
        String jumlahpoin = String.valueOf(poinsiswa-poinpelanggaran);
        txtJumlahPoin.setText(jumlahpoin);
    }
    
    public void SimpanData(){
        String nis = txtNIS.getText();
        String pelanggaran = cmbPelanggaran.getSelectedItem().toString();
        String petugas = txtPetugas.getText();
        try{
            Statement stmt = koneksi.createStatement();
            String query = "INSERT INTO t_datapelanggaran(nis, no_pelanggaran, id_petugas) "
                    + "VALUES('"+nis+"', (SELECT no_pelanggaran FROM t_pelanggaran WHERE jenis_pelanggaran = '"+pelanggaran+"'), "
                    + "(SELECT id_petugas FROM t_petugas WHERE nama_petugas = '"+petugas+"'))";
            System.out.println(query);
            int berhasil = stmt.executeUpdate(query);
            if(berhasil == 1){
                JOptionPane.showMessageDialog(null, "Data berhasil dimasukkan.");
            }else{
                JOptionPane.showMessageDialog(null, "Data gagal dimasukkan!");
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan pada database!");
        }
        System.out.println(petugas);
    }
    
    void showData(String nis){
        try{
            Statement stmt = koneksi.createStatement();
            String query = "SELECT t_siswa.nis, t_siswa.nama_lengkap, t_siswa.kelas, t_pelanggaran.jenis_pelanggaran, t_siswa.poin_siswa, "
                    + "t_pelanggaran.poin_pelanggaran, t_petugas.nama_petugas FROM t_datapelanggaran, t_siswa, t_pelanggaran, t_petugas "
                    + "WHERE t_datapelanggaran.nis = t_siswa.nis AND t_datapelanggaran.no_pelanggaran = t_pelanggaran.no_pelanggaran AND "
                    + "t_datapelanggaran.id_petugas = t_petugas.id_petugas AND t_datapelanggaran.nis = '"+nis+"'";
           
            ResultSet rs = stmt.executeQuery(query);
            rs.first();
            int poinsiswa = rs.getInt("poin_siswa");
            int poinpelanggaran = rs.getInt("poin_pelanggaran");
            String jumlahpoin = String.valueOf(poinsiswa-poinpelanggaran);
            txtNIS.setText(rs.getString("nis"));
            txtNama.setText(rs.getString("nama_lengkap"));
            cmbKelas.setSelectedItem(rs.getString("kelas"));
            //Error, and i don't know to solve it.
            //cmbPelanggaran.setSelectedItem(rs.getString("jenis_pelanggaran"));
            txtPoinSiswa.setText(rs.getString("poin_siswa"));
            txtPoinPelanggaran.setText(rs.getString("poin_pelanggaran"));
            txtJumlahPoin.setText(jumlahpoin);
            txtPetugas.setText(rs.getString("nama_petugas"));
        }catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan di query");
        }
    }
    
    public void EditData(){
        String nis = txtNIS.getText();
        String pelanggaran = cmbPelanggaran.getSelectedItem().toString();
        String no_pelanggaran = null;
        
        if(pelanggaran.equals("Terlambat datang ke sekolah")){
            no_pelanggaran = "001";
        }else if(pelanggaran.equals("Sepatu tidak sesuai aturan")){
            no_pelanggaran = "002";
        }else if(pelanggaran.equals("Celana/rok tidak sesuai aturan")){
            no_pelanggaran = "003";
        }else if(pelanggaran.equals("Rambut tidak sesuai aturan")){
            no_pelanggaran = "004";
        }else if(pelanggaran.equals("Pakaian tidak sesuai hari")){
            no_pelanggaran = "005";
        }
        
        try{
            Statement stmt = koneksi.createStatement();
            String query = "UPDATE t_datapelanggaran SET no_pelanggaran = '"+no_pelanggaran+"' "
                    + "WHERE nis = '"+nis+"'";
            
            System.out.println(query);
            int berhasil = stmt.executeUpdate(query);
            if(berhasil == 1){
                JOptionPane.showMessageDialog(null, "Data berhasil diubah");
            }else{
                JOptionPane.showMessageDialog(null, "Data gagal diubah");
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan pada query");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        lblTitle = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();
        lblNIS = new javax.swing.JLabel();
        lblNama = new javax.swing.JLabel();
        lblKelas = new javax.swing.JLabel();
        lblPelanggaran = new javax.swing.JLabel();
        lblPoinSiswa = new javax.swing.JLabel();
        lblPoinPelanggaran = new javax.swing.JLabel();
        lblJumlahPoin = new javax.swing.JLabel();
        lblPetugas = new javax.swing.JLabel();
        txtNIS = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        cmbKelas = new javax.swing.JComboBox<>();
        cmbPelanggaran = new javax.swing.JComboBox<>();
        txtPoinSiswa = new javax.swing.JTextField();
        txtPoinPelanggaran = new javax.swing.JTextField();
        txtJumlahPoin = new javax.swing.JTextField();
        txtPetugas = new javax.swing.JTextField();
        btnSimpan = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(45, 156, 219));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));

        lblTitle.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(250, 250, 250));
        lblTitle.setText("TAMBAH DATA PELANGGARAN");

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/logo smkn 4 bdg.png"))); // NOI18N

        lblNIS.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblNIS.setForeground(new java.awt.Color(250, 250, 250));
        lblNIS.setText("NIS");

        lblNama.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblNama.setForeground(new java.awt.Color(250, 250, 250));
        lblNama.setText("Nama");

        lblKelas.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblKelas.setForeground(new java.awt.Color(250, 250, 250));
        lblKelas.setText("Kelas");

        lblPelanggaran.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPelanggaran.setForeground(new java.awt.Color(250, 250, 250));
        lblPelanggaran.setText("Pelanggaran");

        lblPoinSiswa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPoinSiswa.setForeground(new java.awt.Color(250, 250, 250));
        lblPoinSiswa.setText("Poin Siswa");

        lblPoinPelanggaran.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPoinPelanggaran.setForeground(new java.awt.Color(250, 250, 250));
        lblPoinPelanggaran.setText("Poin Pelanggaran");

        lblJumlahPoin.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblJumlahPoin.setForeground(new java.awt.Color(250, 250, 250));
        lblJumlahPoin.setText("Jumlah Poin");

        lblPetugas.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblPetugas.setForeground(new java.awt.Color(250, 250, 250));
        lblPetugas.setText("Petugas");

        txtNIS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtNISKeyPressed(evt);
            }
        });

        cmbKelas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih Kelas -", "X TITL 1", "X TITL 2", "X TOI 1", "X TOI 2", "X AV 1", "X AV 2", "X AV 3", "X RPL 1", "X RPL 2", "X RPL 3", "X TKJ 1", "X TKJ 2", "X MM", "XI TITL 1", "XI TITL 2", "XI TOI 1", "XI TOI 2", "XI AV 1", "XI AV 2", "XI AV 3", "XI AV 3", "XI RPL 1", "XI RPL 2", "XI RPL 3", "XI TKJ 1", "XI TKJ 2", "XI MM", "XII TITL 1", "XII TITL 2", "XII TOI 1", "XII TOI 2", "XII AV 1", "XII AV 2", "XII AV 3", "XII RPL 1", "XII RPL 2", "XII RPL 3", "XII TKJ", "XII MM" }));

        cmbPelanggaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Pilih Jenis Pelanggaran -" }));
        cmbPelanggaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPelanggaranActionPerformed(evt);
            }
        });

        txtPoinSiswa.setEditable(false);

        txtPoinPelanggaran.setEditable(false);

        txtJumlahPoin.setEditable(false);

        txtPetugas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtPetugasKeyPressed(evt);
            }
        });

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblNIS)
                                .addGap(144, 144, 144)
                                .addComponent(txtNIS, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblPoinPelanggaran)
                                        .addComponent(lblJumlahPoin)
                                        .addComponent(lblPetugas))
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtPetugas)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(txtJumlahPoin, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtPoinPelanggaran, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(0, 0, Short.MAX_VALUE))))
                                .addComponent(lblPelanggaran)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(lblNama)
                                                .addGap(125, 125, 125))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(lblKelas)
                                                .addGap(129, 129, 129)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(lblPoinSiswa)
                                            .addGap(81, 81, 81)))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cmbKelas, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtNama)
                                        .addComponent(cmbPelanggaran, 0, 350, Short.MAX_VALUE)
                                        .addComponent(txtPoinSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(lblTitle)
                .addGap(100, 100, 100))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSimpan)
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblLogo)
                        .addGap(11, 11, 11))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTitle)
                        .addGap(31, 31, 31)))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNIS)
                    .addComponent(txtNIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNama)
                    .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKelas)
                    .addComponent(cmbKelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPelanggaran)
                    .addComponent(cmbPelanggaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPoinSiswa)
                    .addComponent(txtPoinSiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPoinPelanggaran)
                    .addComponent(txtPoinPelanggaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblJumlahPoin)
                    .addComponent(txtJumlahPoin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPetugas)
                    .addComponent(txtPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(btnSimpan)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
        if(action.equals("Edit")) EditData();
        else SimpanData();
        dispose();
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void txtNISKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNISKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            DataSiswa();
        }
    }//GEN-LAST:event_txtNISKeyPressed

    private void cmbPelanggaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPelanggaranActionPerformed
        // TODO add your handling code here:
        SelectedPelanggaran();
        JumlahPoin();
    }//GEN-LAST:event_cmbPelanggaranActionPerformed

    private void txtPetugasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPetugasKeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            SimpanData();
            dispose();
        }
    }//GEN-LAST:event_txtPetugasKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageDataPelanggaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageDataPelanggaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageDataPelanggaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageDataPelanggaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSimpan;
    private javax.swing.JComboBox<String> cmbKelas;
    private javax.swing.JComboBox<String> cmbPelanggaran;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblJumlahPoin;
    private javax.swing.JLabel lblKelas;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblNIS;
    private javax.swing.JLabel lblNama;
    private javax.swing.JLabel lblPelanggaran;
    private javax.swing.JLabel lblPetugas;
    private javax.swing.JLabel lblPoinPelanggaran;
    private javax.swing.JLabel lblPoinSiswa;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtJumlahPoin;
    private javax.swing.JTextField txtNIS;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtPetugas;
    private javax.swing.JTextField txtPoinPelanggaran;
    private javax.swing.JTextField txtPoinSiswa;
    // End of variables declaration//GEN-END:variables
}
