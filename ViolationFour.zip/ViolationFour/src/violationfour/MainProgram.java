/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package violationfour;

import views.Login;

/**
 *
 * @author Admin
 */
public class MainProgram {
    
    public static Petugas petugas = new Petugas();
    public static Siswa siswa = new Siswa();
    public static Pelanggaran pelanggar = new Pelanggaran();
    
    public static void main(String[] args) {
        // TODO code application logic here
        Login log = new Login();
        log.setVisible(true);
    }
    
}
