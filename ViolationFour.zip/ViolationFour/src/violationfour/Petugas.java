/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package violationfour;

/**
 *
 * @author Admin
 */
public class Petugas extends WargaSekolah{
    private String username;
    private String password;
    
    
    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }
    
    public String getpassword(){
        return password;
    }
    
    public void setpassword(String password) {
        this.password = password;
    }
    
}
