/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package violationfour;

/**
 *
 * @author Admin
 */
public class Siswa extends WargaSekolah {
    private String NIS;
    private String kelas;
    private String poin;
    
	public String getNIS() {
		return NIS;
	}
	public void setNIS(String nis) {
		NIS = nis;
	}
	
	public String getKelas() {
		return kelas;
	}
	public void setKelas(String kelas) {
		this.kelas = kelas;
	}
	
	public String getPoin() {
		return poin;
	}
	public void setPoin(String poin) {
		this.poin = poin;
	}
        
    
}
