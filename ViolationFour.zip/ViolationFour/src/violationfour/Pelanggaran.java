/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package violationfour;

/**
 *
 * @author Admin
 */
public class Pelanggaran {
    private String jenis_pelanggaran;
    private String poin_pelanggaran;
	public String getJenis_pelanggaran() {
		return jenis_pelanggaran;
	}
	public void setJenis_pelanggaran(String jenis_pelanggaran) {
		this.jenis_pelanggaran = jenis_pelanggaran;
	}
	
	public String getPoin_pelanggaran() {
		return poin_pelanggaran;
	}
	public void setPoin_pelanggaran(String poin_pelanggaran) {
		this.poin_pelanggaran = poin_pelanggaran;
	}
}
